# AI App
Ready for GitHub Pages and installation.